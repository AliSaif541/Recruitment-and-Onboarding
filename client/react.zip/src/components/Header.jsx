

function Header() {
  return (
    <div>
      <div>Header</div>
    </div>
  );
}

export default Header;