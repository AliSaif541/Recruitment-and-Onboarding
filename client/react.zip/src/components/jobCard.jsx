import { useState, useEffect } from 'react';
import axios from 'axios';

function JobCard(key) {
  return (
    <div>
      <div>jobCard</div>
    </div>
  );
}

export default JobCard;